struct carEngine {
    var V4 = 1500
    var V6 = 5500
    var V8 = 7000
    
}
